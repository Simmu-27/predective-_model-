const $ = id => document.getElementById(id);
const show = (id, v) => $(id).hidden = !v;
const charts = {};
function draw(id, type, labels, values, label) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart($(id), {type, data: {labels, datasets: [{label, data: values,
    borderColor: '#1e6fd9', backgroundColor: '#6db3ffaa', pointRadius: 0, tension: .2}]},
    options: {responsive: true, plugins: {legend: {display: false}}}});
}
async function api(url, opts) {
  const r = await fetch(url, opts); const j = await r.json();
  if (!r.ok || !j.success) throw new Error(j.error || 'Request failed');
  return j;
}
async function init() {
  try { const h = await api('/api/health');
    $('status').textContent = h.model_loaded ? '● Backend online, model loaded' : '● Backend online, model NOT loaded';
  } catch (e) { $('status').textContent = '● Backend offline'; return; }
  try {
    const a = await api('/api/analytics'), s = a.summary;
    $('summary').innerHTML = [['Records', s.records], ['From', s.start], ['To', s.end],
      ['Mean °C', s.mean.toFixed(1)], ['Min °C', s.min.toFixed(1)], ['Max °C', s.max.toFixed(1)]]
      .map(([k, v]) => `<div class="card"><small>${k}</small><h3>${v}</h3></div>`).join('');
    draw('trend', 'line', a.monthly_trend.labels, a.monthly_trend.values, 'Monthly mean °C');
    draw('monthly', 'bar', a.monthly_average.labels, a.monthly_average.values, 'Mean °C');
    draw('corr', 'bar', a.correlation.labels, a.correlation.values, 'Correlation');
    const m = await api('/api/model-metrics');
    $('period').textContent = `Test period: ${m.test_period[0]} to ${m.test_period[1]}`;
    $('metrics').innerHTML = Object.entries(m.metrics).map(([n, v]) =>
      `<tr><td>${n}${m.best_model === n ? ' ⭐' : ''}</td><td>${v.MAE.toFixed(3)}</td><td>${v.RMSE.toFixed(3)}</td><td>${v.R2.toFixed(3)}</td></tr>`).join('');
    $('best').textContent = `Best model chosen by cross-validated MAE on training data: ${m.best_model}. Compare its test scores with the persistence baseline above.`;
    $('model').innerHTML = Object.keys(m.metrics).filter(n => !n.startsWith('Persistence'))
      .map(n => `<option ${n === m.best_model ? 'selected' : ''}>${n}</option>`).join('');
  } catch (e) { $('error').textContent = e.message; show('error', true); }
}
$('form').addEventListener('submit', async ev => {
  ev.preventDefault(); show('error', false); show('result', false);
  const body = {date: $('date').value, model: $('model').value};
  body.history = $('history').value;
  if (!body.date) { $('error').textContent = 'Select a date.'; show('error', true); return; }
  show('loading', true);
  try {
    const r = await api('/api/predict', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
    $('temp').textContent = r.prediction_c; $('rdate').textContent = r.date; $('rmodel').textContent = r.model; show('result', true);
  } catch (e) { $('error').textContent = e.message; show('error', true); }
  show('loading', false);
});
$('reset').addEventListener('click', () => { $('form').reset(); show('error', false); show('result', false); });
init();
